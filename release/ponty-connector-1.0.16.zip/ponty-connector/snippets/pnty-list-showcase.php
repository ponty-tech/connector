<?php
    $q = array('post_type'=>PNTY_PTNAME_SHOWCASE, 'numberposts'=>$a['numberposts']);
    if ($a['tag']) {
        $q['tax_query'] = array(array(
            'taxonomy' => PNTY_PTNAME.'_tag',
            'field' => 'slug',
            'terms' => explode('|', $a['tag'])
        ));
    }
    $jobs = get_posts($q);
    $pnty_extcss = get_option('pnty_extcss');
?>
<?php if (count($jobs) > 0):?>
    <?php if ( ! is_null($pnty_extcss) && ! empty($pnty_extcss)):?>
        <link rel="stylesheet" href="<?php echo $pnty_extcss;?>" />
    <?php endif; ?>
    <ul class="pnty-list<?php echo ($a['class'])?' '.$a['class']:'';?>">
        <?php global $post; foreach($jobs as $post): setup_postdata($post);?>
            <?php
                $metadata = get_post_custom($post->ID);
                $logo = pnty_get_logo($post->ID);
                $logo_url = $logo['url'];
            ?>
            <li>
                <?php if ($a['hero'] && has_post_thumbnail($post->ID)): ?>
                <span class="pnty-list-hero"><?php echo get_the_post_thumbnail($post->ID, $a['hero_size'], array('class' => 'pnty-list-hero-img'));?></span>
                <?php endif; ?>
                <?php echo $post->post_title;?>
                <?php if ($logo_url && $a['logo']): ?>
                <img class="pnty-list-logo" src="<?php echo $logo_url;?>" width="<?php echo $a['logo_width'];?>" alt="<?php _e('Client logotype', 'pnty');?>" />
                <?php endif; ?>
                <?php if ($a['organization_name']): ?>
                    <span class="pnty-list-organization-name"><?php echo get_post_meta($post->ID, '_pnty_organization_name', true);?></span>
                <?php endif; ?>
                <?php if ($a['location'] && ($metadata['_pnty_location'][0] ?? false)): ?>
                    <span class="pnty-list-location"><?php echo $metadata['_pnty_location'][0];?></span>
                <?php endif; ?>
                <?php if ($a['excerpt']): ?>
                    <p class="pnty-list-excerpt"><?php echo get_the_excerpt();?></p>
                <?php endif; ?>
            </li>
        <?php endforeach; wp_reset_postdata();?>
    </ul>
<?php else: ?>
    <p><?php echo $a['empty_msg'];?></p>
<?php endif; ?>
